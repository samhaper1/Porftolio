"use client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CallToAction from "@/components/CallToAction";
import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";

// Category data
const categories = [
  { id: "all", name: "All Projects" },
  { id: "restaurant", name: "Restaurant" },
  { id: "hotel", name: "Hotel Reservation" },
  { id: "tech", name: "Tech & IT" },
  { id: "clothing", name: "Clothing & Fashion" },
  { id: "ecommerce", name: "E-commerce" },
  { id: "landing", name: "Landing Pages" },
  { id: "portfolio", name: "Portfolio Sites" },
];

// Project data organized by category
const projects = [
  {
    id: "restaurant1",
    title: "Bistro Elegance",
    description: "Modern restaurant website with online ordering system",
    imageSrc: "https://placehold.co/600x400/333/white?text=Restaurant+Project",
    categories: ["restaurant", "ecommerce"],
    link: "/projects/bistro-elegance",
  },
  {
    id: "restaurant2",
    title: "Spice Garden",
    description: "Traditional cuisine restaurant with table reservations",
    imageSrc: "https://placehold.co/600x400/333/white?text=Restaurant+Project+2",
    categories: ["restaurant"],
    link: "/projects/spice-garden",
  },
  {
    id: "hotel1",
    title: "Ocean Resort",
    description: "Luxury hotel with advanced booking system",
    imageSrc: "https://placehold.co/600x400/333/white?text=Hotel+Project",
    categories: ["hotel"],
    link: "/projects/ocean-resort",
  },
  {
    id: "hotel2",
    title: "Mountain Retreat",
    description: "Cozy mountain hotel with spa reservation features",
    imageSrc: "https://placehold.co/600x400/333/white?text=Hotel+Project+2",
    categories: ["hotel"],
    link: "/projects/mountain-retreat",
  },
  {
    id: "tech1",
    title: "TechSolutions Inc.",
    description: "IT company product showcase and service platform",
    imageSrc: "https://placehold.co/600x400/333/white?text=Tech+Project",
    categories: ["tech"],
    link: "/projects/tech-solutions",
  },
  {
    id: "tech2",
    title: "Gadget World",
    description: "Technology store with inventory management",
    imageSrc: "https://placehold.co/600x400/333/white?text=Tech+Project+2",
    categories: ["tech", "ecommerce"],
    link: "/projects/gadget-world",
  },
  {
    id: "clothing1",
    title: "Fashion Forward",
    description: "Modern clothing brand with seasonal collections",
    imageSrc: "https://placehold.co/600x400/333/white?text=Clothing+Project",
    categories: ["clothing", "ecommerce"],
    link: "/projects/fashion-forward",
  },
  {
    id: "clothing2",
    title: "Urban Style",
    description: "Street fashion boutique with virtual fitting room",
    imageSrc: "https://placehold.co/600x400/333/white?text=Clothing+Project+2",
    categories: ["clothing"],
    link: "/projects/urban-style",
  },
  {
    id: "ecommerce1",
    title: "Market Plus",
    description: "Multi-vendor marketplace with integrated payment system",
    imageSrc: "https://placehold.co/600x400/333/white?text=Ecommerce+Project",
    categories: ["ecommerce"],
    link: "/projects/market-plus",
  },
  {
    id: "ecommerce2",
    title: "Artisan Crafts",
    description: "Handmade products store with artist profiles",
    imageSrc: "https://placehold.co/600x400/333/white?text=Ecommerce+Project+2",
    categories: ["ecommerce"],
    link: "/projects/artisan-crafts",
  },
  {
    id: "landing1",
    title: "App Launch",
    description: "Mobile app promotional landing page with download metrics",
    imageSrc: "https://placehold.co/600x400/333/white?text=Landing+Page",
    categories: ["landing"],
    link: "/projects/app-launch",
  },
  {
    id: "landing2",
    title: "Event Conference",
    description: "Annual tech conference registration landing page",
    imageSrc: "https://placehold.co/600x400/333/white?text=Landing+Page+2",
    categories: ["landing"],
    link: "/projects/event-conference",
  },
  {
    id: "portfolio1",
    title: "Creative Designer",
    description: "Visual artist portfolio with interactive galleries",
    imageSrc: "https://placehold.co/600x400/333/white?text=Portfolio+Project",
    categories: ["portfolio"],
    link: "/projects/creative-designer",
  },
  {
    id: "portfolio2",
    title: "Architect Studio",
    description: "Architecture firm portfolio with 3D project showcase",
    imageSrc: "https://placehold.co/600x400/333/white?text=Portfolio+Project+2",
    categories: ["portfolio"],
    link: "/projects/architect-studio",
  },
];

export default function WorkPage() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [filteredProjects, setFilteredProjects] = useState(projects);

  // Filter projects when category changes
  useEffect(() => {
    if (activeCategory === "all") {
      setFilteredProjects(projects);
    } else {
      setFilteredProjects(
        projects.filter((project) =>
          project.categories.includes(activeCategory)
        )
      );
    }
  }, [activeCategory]);

  // Set language based on user's browser on client-side
  useEffect(() => {
    const detectUserLanguage = () => {
      const language = navigator.language || "en";
      if (language.startsWith("ar")) document.documentElement.dir = "rtl";
      else document.documentElement.dir = "ltr";
    };

    detectUserLanguage();
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <section className="py-20 bg-buildora-dark text-white">
          <div className="container mx-auto px-6 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Work</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Explore our portfolio of projects across various industries. From restaurants to e-commerce, we've built beautiful, functional websites for diverse clients.
            </p>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-6">
            {/* Category Filter */}
            <div className="mb-12">
              <div className="flex flex-wrap justify-center gap-4">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setActiveCategory(category.id)}
                    className={`px-4 py-2 rounded-md transition-colors ${
                      activeCategory === category.id
                        ? "bg-buildora-dark text-white"
                        : "bg-gray-100 text-gray-800 hover:bg-gray-200"
                    }`}
                  >
                    {category.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Projects Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProjects.map((project) => (
                <div
                  key={project.id}
                  className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300"
                >
                  <div className="relative h-64">
                    <Image
                      src={project.imageSrc}
                      alt={project.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                    <p className="text-gray-600 mb-4">{project.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.categories.map((cat) => {
                        const categoryName = categories.find((c) => c.id === cat)?.name || cat;
                        return (
                          <span
                            key={cat}
                            className="text-xs font-medium bg-gray-100 px-2 py-1 rounded"
                          >
                            {categoryName}
                          </span>
                        );
                      })}
                    </div>
                    <Link
                      href={project.link}
                      className="text-buildora-accent hover:text-buildora-dark font-medium inline-flex items-center"
                    >
                      View Project
                      <svg
                        className="w-4 h-4 ml-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M14 5l7 7m0 0l-7 7m7-7H3"
                        />
                      </svg>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <CallToAction />
      </main>
      <Footer />
    </div>
  );
}
