"use client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import MultilingualForm from "@/components/MultilingualForm";
import { useEffect } from "react";

export default function ContactPage() {
  // Set language based on user's browser on client-side
  useEffect(() => {
    const detectUserLanguage = () => {
      const language = navigator.language || "en";
      if (language.startsWith("ar")) document.documentElement.dir = "rtl";
      else document.documentElement.dir = "ltr";
    };

    detectUserLanguage();
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <section className="py-20 bg-buildora-dark text-white">
          <div className="container mx-auto px-6 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Contact Us</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Ready to start your project? Fill out the form below and we'll get back to you as soon as possible.
            </p>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-6">
            <MultilingualForm />
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
