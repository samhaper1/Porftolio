"use client";

import Header from "@/components/Header";
import Hero from "@/components/Hero";
import ServicesSection from "@/components/ServicesSection";
import MultilingualForm from "@/components/MultilingualForm";
import FeaturedProjects from "@/components/FeaturedProjects";
import CallToAction from "@/components/CallToAction";
import Footer from "@/components/Footer";
import { useEffect } from "react";

export default function Home() {
  // Set language based on user's browser on client-side
  useEffect(() => {
    const detectUserLanguage = () => {
      const language = navigator.language || "en";
      if (language.startsWith("ar")) document.documentElement.dir = "rtl";
      else document.documentElement.dir = "ltr";
    };

    detectUserLanguage();
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <Hero />
        <ServicesSection />
        <section className="py-20 bg-gray-100">
          <div className="container mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">
                Start Your Project
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Tell us about your project and we'll help you bring your vision to life.
              </p>
            </div>
            <MultilingualForm />
          </div>
        </section>
        <FeaturedProjects />
        <CallToAction />
      </main>
      <Footer />
    </div>
  );
}
