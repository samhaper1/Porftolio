"use client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CallToAction from "@/components/CallToAction";
import { useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { CheckCircle } from "lucide-react";

// Sample features
const techFeatures = [
  "Modern and innovative designs that reflect your tech brand identity",
  "Interactive UI/UX design optimized for user engagement",
  "Integration with various tech platforms and APIs",
  "Product showcases with immersive demonstrations",
  "Technical documentation sections with searchable content",
  "Responsive design for all devices and screen sizes",
  "Lead generation forms tailored for tech customers",
  "Analytics integration for measuring user engagement",
  "Performance optimization for fast loading speed",
  "Security implementation to protect sensitive information",
];

// Sample tech website projects
const techProjects = [
  {
    id: "tech1",
    title: "TechSolutions Inc.",
    description: "IT company product showcase and service platform",
    imageSrc: "https://placehold.co/600x400/333/white?text=Tech+Project",
    link: "/projects/tech-solutions",
  },
  {
    id: "tech2",
    title: "Gadget World",
    description: "Technology store with inventory management",
    imageSrc: "https://placehold.co/600x400/333/white?text=Tech+Project+2",
    link: "/projects/gadget-world",
  },
];

export default function TechWebsitesPage() {
  // Set language based on user's browser on client-side
  useEffect(() => {
    const detectUserLanguage = () => {
      const language = navigator.language || "en";
      if (language.startsWith("ar")) document.documentElement.dir = "rtl";
      else document.documentElement.dir = "ltr";
    };

    detectUserLanguage();
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <section className="py-20 bg-buildora-dark text-white">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold mb-6">
                  Tech & IT Website Development
                </h1>
                <p className="text-xl text-gray-300 mb-8">
                  Showcase your tech products and services with a cutting-edge website that reflects innovation and technical excellence.
                </p>
                <Link
                  href="/contact"
                  className="inline-block bg-white text-buildora-dark hover:bg-gray-200 px-8 py-4 font-medium rounded transition-colors"
                >
                  Get a Quote
                </Link>
              </div>
              <div className="relative h-80 md:h-96">
                <Image
                  src="https://placehold.co/800x600/333/white?text=Tech+Website+Example"
                  alt="Tech Website Example"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Why Your Tech Business Needs a Professional Website
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                In the technology industry, your website is often the first interaction potential clients have with your company. A well-designed tech website communicates your expertise, showcases your products, and generates qualified leads.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="w-16 h-16 bg-buildora-dark text-white rounded-full flex items-center justify-center mb-6">
                  <svg
                    className="w-8 h-8"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-4">Product Showcase</h3>
                <p className="text-gray-600">
                  Effectively demonstrate your tech products and solutions with interactive demonstrations, specifications, and use cases.
                </p>
              </div>

              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="w-16 h-16 bg-buildora-dark text-white rounded-full flex items-center justify-center mb-6">
                  <svg
                    className="w-8 h-8"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-4">Lead Generation</h3>
                <p className="text-gray-600">
                  Capture and convert potential clients with strategically placed contact forms, demo requests, and newsletter signups.
                </p>
              </div>

              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="w-16 h-16 bg-buildora-dark text-white rounded-full flex items-center justify-center mb-6">
                  <svg
                    className="w-8 h-8"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-4">Technical Documentation</h3>
                <p className="text-gray-600">
                  Provide comprehensive, searchable documentation for your products and services to support users and reduce support inquiries.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold mb-6">
                  Features of Our Tech Websites
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  We build tech websites that not only look impressive but also function flawlessly to showcase your technological capabilities and generate business.
                </p>
                <ul className="space-y-4">
                  {techFeatures.map((feature) => (
                    <li key={feature} className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="relative h-80 md:h-96 rounded-lg overflow-hidden">
                <Image
                  src="https://placehold.co/800x600/333/white?text=Tech+Features"
                  alt="Tech Website Features"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Our Tech Website Projects
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Explore some of our tech website projects that have helped businesses showcase their innovations and connect with potential clients.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {techProjects.map((project) => (
                <div
                  key={project.id}
                  className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300"
                >
                  <div className="relative h-64">
                    <Image
                      src={project.imageSrc}
                      alt={project.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                    <p className="text-gray-600 mb-4">{project.description}</p>
                    <Link
                      href={project.link}
                      className="text-buildora-accent hover:text-buildora-dark font-medium inline-flex items-center"
                    >
                      View Project
                      <svg
                        className="w-4 h-4 ml-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M14 5l7 7m0 0l-7 7m7-7H3"
                        />
                      </svg>
                    </Link>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-12 text-center">
              <Link
                href="/work"
                className="inline-flex items-center text-buildora-accent hover:text-buildora-dark font-medium"
              >
                View All Tech Projects
                <svg
                  className="w-4 h-4 ml-2"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M14 5l7 7m0 0l-7 7m7-7H3"
                  />
                </svg>
              </Link>
            </div>
          </div>
        </section>

        <CallToAction />
      </main>
      <Footer />
    </div>
  );
}
