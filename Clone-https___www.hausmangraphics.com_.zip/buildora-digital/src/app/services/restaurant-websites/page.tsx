"use client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CallToAction from "@/components/CallToAction";
import { useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { CheckCircle } from "lucide-react";

// Sample features
const restaurantFeatures = [
  "Professional and modern designs tailored for restaurants",
  "Online menu with high-quality food photography",
  "Easy-to-use reservation system",
  "Mobile-responsive layouts for customers on the go",
  "Integration with food delivery platforms",
  "SEO optimization to attract local customers",
  "Social media integration for showcasing your culinary creations",
  "Customer reviews and testimonials section",
];

// Sample restaurant website projects
const restaurantProjects = [
  {
    id: "restaurant1",
    title: "Bistro Elegance",
    description: "Modern restaurant website with online ordering system",
    imageSrc: "https://placehold.co/600x400/333/white?text=Restaurant+Project",
    link: "/projects/bistro-elegance",
  },
  {
    id: "restaurant2",
    title: "Spice Garden",
    description: "Traditional cuisine restaurant with table reservations",
    imageSrc: "https://placehold.co/600x400/333/white?text=Restaurant+Project+2",
    link: "/projects/spice-garden",
  },
];

export default function RestaurantWebsitesPage() {
  // Set language based on user's browser on client-side
  useEffect(() => {
    const detectUserLanguage = () => {
      const language = navigator.language || "en";
      if (language.startsWith("ar")) document.documentElement.dir = "rtl";
      else document.documentElement.dir = "ltr";
    };

    detectUserLanguage();
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <section className="py-20 bg-buildora-dark text-white">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold mb-6">
                  Restaurant Website Development
                </h1>
                <p className="text-xl text-gray-300 mb-8">
                  Showcase your culinary creations with a beautiful, functional website that drives reservations and online orders.
                </p>
                <Link
                  href="/contact"
                  className="inline-block bg-white text-buildora-dark hover:bg-gray-200 px-8 py-4 font-medium rounded transition-colors"
                >
                  Get a Quote
                </Link>
              </div>
              <div className="relative h-80 md:h-96">
                <Image
                  src="https://placehold.co/800x600/333/white?text=Restaurant+Website+Example"
                  alt="Restaurant Website Example"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Why Your Restaurant Needs a Professional Website
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                In today's digital world, your online presence is often the first impression potential customers have of your restaurant. A well-designed website can entice diners and increase reservations.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="w-16 h-16 bg-buildora-dark text-white rounded-full flex items-center justify-center mb-6">
                  <svg
                    className="w-8 h-8"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-4">Online Ordering</h3>
                <p className="text-gray-600">
                  Allow customers to browse your menu and place orders directly through your website, streamlining operations and increasing sales.
                </p>
              </div>

              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="w-16 h-16 bg-buildora-dark text-white rounded-full flex items-center justify-center mb-6">
                  <svg
                    className="w-8 h-8"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-4">Reservation System</h3>
                <p className="text-gray-600">
                  Implement an easy-to-use booking system that allows guests to make reservations 24/7, reducing phone calls and maximizing table utilization.
                </p>
              </div>

              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="w-16 h-16 bg-buildora-dark text-white rounded-full flex items-center justify-center mb-6">
                  <svg
                    className="w-8 h-8"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-4">Local SEO</h3>
                <p className="text-gray-600">
                  Optimize your website to appear in local search results, helping nearby customers find your restaurant when they're looking for a place to dine.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold mb-6">
                  Features of Our Restaurant Websites
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  We design restaurant websites that not only look appetizing but also serve up a great user experience that converts visitors into diners.
                </p>
                <ul className="space-y-4">
                  {restaurantFeatures.map((feature) => (
                    <li key={feature} className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="relative h-80 md:h-96 rounded-lg overflow-hidden">
                <Image
                  src="https://placehold.co/800x600/333/white?text=Restaurant+Features"
                  alt="Restaurant Website Features"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Our Restaurant Website Projects
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Take a look at some of the restaurant websites we've created that have helped businesses attract more customers and increase revenue.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {restaurantProjects.map((project) => (
                <div
                  key={project.id}
                  className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300"
                >
                  <div className="relative h-64">
                    <Image
                      src={project.imageSrc}
                      alt={project.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                    <p className="text-gray-600 mb-4">{project.description}</p>
                    <Link
                      href={project.link}
                      className="text-buildora-accent hover:text-buildora-dark font-medium inline-flex items-center"
                    >
                      View Project
                      <svg
                        className="w-4 h-4 ml-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M14 5l7 7m0 0l-7 7m7-7H3"
                        />
                      </svg>
                    </Link>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-12 text-center">
              <Link
                href="/work"
                className="inline-flex items-center text-buildora-accent hover:text-buildora-dark font-medium"
              >
                View All Restaurant Projects
                <svg
                  className="w-4 h-4 ml-2"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M14 5l7 7m0 0l-7 7m7-7H3"
                  />
                </svg>
              </Link>
            </div>
          </div>
        </section>

        <CallToAction />
      </main>
      <Footer />
    </div>
  );
}
