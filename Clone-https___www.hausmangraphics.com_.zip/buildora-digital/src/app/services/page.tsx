"use client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ServicesSection from "@/components/ServicesSection";
import CallToAction from "@/components/CallToAction";
import { useEffect } from "react";

export default function ServicesPage() {
  // Set language based on user's browser on client-side
  useEffect(() => {
    const detectUserLanguage = () => {
      const language = navigator.language || "en";
      if (language.startsWith("ar")) document.documentElement.dir = "rtl";
      else document.documentElement.dir = "ltr";
    };

    detectUserLanguage();
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <section className="py-20 bg-buildora-dark text-white">
          <div className="container mx-auto px-6 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              We offer a range of digital services to help your business succeed online.
            </p>
          </div>
        </section>

        <ServicesSection />

        <section className="py-20 bg-gray-100">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div>
                <h2 className="text-3xl font-bold mb-6">Custom Website Development</h2>
                <p className="text-lg text-gray-700 mb-4">
                  We create bespoke websites tailored to your specific needs. Our websites are:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>Mobile-responsive and fast-loading</li>
                  <li>Search engine optimized</li>
                  <li>User-friendly with intuitive navigation</li>
                  <li>Secure and reliable</li>
                  <li>Scalable to grow with your business</li>
                </ul>
              </div>

              <div>
                <h2 className="text-3xl font-bold mb-6">Digital Marketing Solutions</h2>
                <p className="text-lg text-gray-700 mb-4">
                  Drive traffic, generate leads, and increase conversions with our comprehensive digital marketing services:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>Search Engine Optimization (SEO)</li>
                  <li>Content Marketing</li>
                  <li>Social Media Marketing</li>
                  <li>Email Marketing</li>
                  <li>Pay-Per-Click (PPC) Advertising</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <CallToAction />
      </main>
      <Footer />
    </div>
  );
}
