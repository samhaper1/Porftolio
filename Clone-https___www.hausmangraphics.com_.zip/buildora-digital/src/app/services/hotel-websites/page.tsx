"use client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CallToAction from "@/components/CallToAction";
import { useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { CheckCircle } from "lucide-react";

// Sample features
const hotelFeatures = [
  "Elegant and luxurious designs that reflect your hotel's brand",
  "Integrated booking system with real-time availability calendar",
  "Room type showcases with high-quality photography",
  "Mobile-responsive design for travelers on the go",
  "Virtual tour integration for room previews",
  "Multilingual support for international guests",
  "Amenities and services presentation",
  "Local attractions and activities section",
  "Guest reviews and testimonials display",
];

// Sample hotel website projects
const hotelProjects = [
  {
    id: "hotel1",
    title: "Ocean Resort",
    description: "Luxury hotel with advanced booking system",
    imageSrc: "https://placehold.co/600x400/333/white?text=Hotel+Project",
    link: "/projects/ocean-resort",
  },
  {
    id: "hotel2",
    title: "Mountain Retreat",
    description: "Cozy mountain hotel with spa reservation features",
    imageSrc: "https://placehold.co/600x400/333/white?text=Hotel+Project+2",
    link: "/projects/mountain-retreat",
  },
];

export default function HotelWebsitesPage() {
  // Set language based on user's browser on client-side
  useEffect(() => {
    const detectUserLanguage = () => {
      const language = navigator.language || "en";
      if (language.startsWith("ar")) document.documentElement.dir = "rtl";
      else document.documentElement.dir = "ltr";
    };

    detectUserLanguage();
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <section className="py-20 bg-buildora-dark text-white">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold mb-6">
                  Hotel Reservation Website Development
                </h1>
                <p className="text-xl text-gray-300 mb-8">
                  Showcase your hotel rooms and amenities with a beautiful website that simplifies bookings and increases direct reservations.
                </p>
                <Link
                  href="/contact"
                  className="inline-block bg-white text-buildora-dark hover:bg-gray-200 px-8 py-4 font-medium rounded transition-colors"
                >
                  Get a Quote
                </Link>
              </div>
              <div className="relative h-80 md:h-96">
                <Image
                  src="https://placehold.co/800x600/333/white?text=Hotel+Website+Example"
                  alt="Hotel Website Example"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Why Your Hotel Needs a Professional Booking Website
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                A well-designed hotel website not only showcases your property in the best light but also provides a seamless booking experience, reducing dependency on third-party booking platforms and their commissions.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="w-16 h-16 bg-buildora-dark text-white rounded-full flex items-center justify-center mb-6">
                  <svg
                    className="w-8 h-8"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-4">Direct Bookings</h3>
                <p className="text-gray-600">
                  Increase your revenue by accepting direct bookings without paying commissions to third-party platforms, offering special deals to website visitors.
                </p>
              </div>

              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="w-16 h-16 bg-buildora-dark text-white rounded-full flex items-center justify-center mb-6">
                  <svg
                    className="w-8 h-8"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-4">Virtual Tours</h3>
                <p className="text-gray-600">
                  Allow potential guests to explore your rooms, facilities, and common areas virtually, helping them make informed booking decisions.
                </p>
              </div>

              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="w-16 h-16 bg-buildora-dark text-white rounded-full flex items-center justify-center mb-6">
                  <svg
                    className="w-8 h-8"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-4">Multilingual Support</h3>
                <p className="text-gray-600">
                  Cater to international travelers with multilingual website support, making it easier for guests from different countries to book with you.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold mb-6">
                  Features of Our Hotel Reservation Websites
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  We create hotel websites that not only showcase your property beautifully but also streamline the booking process to convert visitors into guests.
                </p>
                <ul className="space-y-4">
                  {hotelFeatures.map((feature) => (
                    <li key={feature} className="flex items-start">
                      <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="relative h-80 md:h-96 rounded-lg overflow-hidden">
                <Image
                  src="https://placehold.co/800x600/333/white?text=Hotel+Features"
                  alt="Hotel Website Features"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">
                Our Hotel Website Projects
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Explore some of our hotel website projects that have helped properties increase direct bookings and enhance their online presence.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {hotelProjects.map((project) => (
                <div
                  key={project.id}
                  className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300"
                >
                  <div className="relative h-64">
                    <Image
                      src={project.imageSrc}
                      alt={project.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                    <p className="text-gray-600 mb-4">{project.description}</p>
                    <Link
                      href={project.link}
                      className="text-buildora-accent hover:text-buildora-dark font-medium inline-flex items-center"
                    >
                      View Project
                      <svg
                        className="w-4 h-4 ml-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M14 5l7 7m0 0l-7 7m7-7H3"
                        />
                      </svg>
                    </Link>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-12 text-center">
              <Link
                href="/work"
                className="inline-flex items-center text-buildora-accent hover:text-buildora-dark font-medium"
              >
                View All Hotel Projects
                <svg
                  className="w-4 h-4 ml-2"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M14 5l7 7m0 0l-7 7m7-7H3"
                  />
                </svg>
              </Link>
            </div>
          </div>
        </section>

        <CallToAction />
      </main>
      <Footer />
    </div>
  );
}
