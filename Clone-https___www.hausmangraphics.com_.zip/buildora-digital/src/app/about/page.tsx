"use client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CallToAction from "@/components/CallToAction";
import { useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle } from "lucide-react";

// Core values of the agency
const coreValues = [
  {
    title: "Quality",
    description: "We never compromise on quality and always strive for excellence in every project we undertake.",
  },
  {
    title: "Innovation",
    description: "We stay ahead of the curve with cutting-edge technology and creative approaches to web design.",
  },
  {
    title: "Customer Focus",
    description: "Your success is our success. We listen, understand, and deliver solutions tailored to your unique needs.",
  },
  {
    title: "Transparency",
    description: "We believe in clear communication and keeping our clients informed throughout the entire process.",
  },
];

export default function AboutPage() {
  // Set language based on user's browser on client-side
  useEffect(() => {
    const detectUserLanguage = () => {
      const language = navigator.language || "en";
      if (language.startsWith("ar")) document.documentElement.dir = "rtl";
      else document.documentElement.dir = "ltr";
    };

    detectUserLanguage();
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-buildora-dark text-white py-24">
          <div className="container mx-auto px-6 text-center">
            <h1 className="text-5xl md:text-6xl font-bold mb-4">About Us</h1>
          </div>
        </section>

        {/* About Digital Agency Section */}
        <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <span className="text-buildora-accent font-medium">About Buildora Digital</span>
              <h2 className="text-4xl md:text-5xl font-bold mt-4 mb-8">Our Journey, Mission, and Values</h2>
            </div>

            <div className="max-w-4xl mx-auto space-y-8 text-lg">
              <p>
                At Buildora Digital, we've helped countless businesses and individuals establish a strong online presence. With a focus on modern web development, we blend creativity, technical expertise, and a deep understanding of user experience to build websites that deliver.
              </p>
              <p>
                Our mission is to empower businesses with world-class websites that are not only visually stunning but also highly functional and result-driven. We understand that in today's digital landscape, your website is often the first interaction potential customers have with your brand, and we're dedicated to making that first impression count.
              </p>
              <p>
                Founded in 2018, our team of experienced designers, developers, and digital marketers has worked across various industries, from restaurants and hotels to tech companies and e-commerce businesses. This diverse experience allows us to bring a unique perspective to each project, ensuring that we deliver solutions that are tailored to your specific needs and goals.
              </p>
            </div>

            <div className="mt-16">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div className="relative h-96">
                  <Image
                    src="https://placehold.co/800x600/333/white?text=Buildora+Team"
                    alt="Buildora Digital Team"
                    fill
                    className="object-cover rounded-lg"
                  />
                </div>
                <div className="flex flex-col justify-center">
                  <h3 className="text-3xl font-bold mb-6">Who We Are</h3>
                  <p className="text-lg mb-8">
                    We are a team of passionate digital creators committed to transforming your online presence. Our expertise spans web design, development, SEO, content creation, and digital marketing – all the tools you need to succeed in the digital world.
                  </p>
                  <Button
                    asChild
                    className="bg-buildora-dark hover:bg-buildora-accent text-white w-fit"
                  >
                    <Link href="/contact">
                      Get to Know Our Team <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Core Values Section */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Core Values</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                These principles guide everything we do and shape how we work with our clients to deliver exceptional results.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {coreValues.map((value, index) => (
                <div key={value.title} className="bg-white p-8 rounded-lg shadow-md">
                  <div className="w-12 h-12 bg-buildora-dark text-white rounded-full flex items-center justify-center mb-6">
                    <span className="font-bold text-xl">{index + 1}</span>
                  </div>
                  <h3 className="text-xl font-bold mb-4">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Why Choose Us Section */}
        <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-8">Why Choose Buildora Digital</h2>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mr-3 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-bold text-xl mb-2">Expertise That Delivers</h3>
                      <p className="text-gray-600">Our team combines years of experience with the latest industry knowledge to create websites that stand out and perform.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mr-3 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-bold text-xl mb-2">Tailored Solutions</h3>
                      <p className="text-gray-600">We don't believe in one-size-fits-all. Every project is unique, and we design custom solutions that address your specific needs.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mr-3 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-bold text-xl mb-2">Result-Driven Approach</h3>
                      <p className="text-gray-600">We focus on creating websites that not only look great but also drive real business results - increased traffic, leads, and conversions.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mr-3 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-bold text-xl mb-2">Ongoing Support</h3>
                      <p className="text-gray-600">Our relationship doesn't end when your website launches. We provide continued support to ensure your digital presence thrives.</p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="relative h-96">
                <Image
                  src="https://placehold.co/800x600/333/white?text=Why+Choose+Us"
                  alt="Why Choose Buildora Digital"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Our Process Section */}
        <section className="py-20 bg-buildora-dark text-white">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Process</h2>
              <p className="text-lg text-gray-300 max-w-3xl mx-auto">
                We follow a structured approach to ensure every project is completed efficiently and meets the highest standards of quality.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-white text-buildora-dark rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="font-bold text-xl">1</span>
                </div>
                <h3 className="text-xl font-bold mb-4">Discovery</h3>
                <p className="text-gray-300">We start by understanding your business, goals, and target audience to create a strategic foundation.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-white text-buildora-dark rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="font-bold text-xl">2</span>
                </div>
                <h3 className="text-xl font-bold mb-4">Design</h3>
                <p className="text-gray-300">Our designers create engaging visuals and user experiences that align with your brand identity.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-white text-buildora-dark rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="font-bold text-xl">3</span>
                </div>
                <h3 className="text-xl font-bold mb-4">Development</h3>
                <p className="text-gray-300">We build your website with clean code and cutting-edge technologies for optimal performance.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-white text-buildora-dark rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="font-bold text-xl">4</span>
                </div>
                <h3 className="text-xl font-bold mb-4">Delivery</h3>
                <p className="text-gray-300">After thorough testing, we launch your website and provide ongoing support to ensure continued success.</p>
              </div>
            </div>
          </div>
        </section>

        <CallToAction />
      </main>
      <Footer />
    </div>
  );
}
