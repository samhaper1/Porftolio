import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function CallToAction() {
  return (
    <section className="bg-buildora-dark text-white py-16">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-8">LET'S GET STARTED</h2>
        <p className="text-lg text-gray-300 max-w-2xl mx-auto mb-10">
          Ready to transform your online presence? Tell us about your project and let's create something amazing together.
        </p>
        <Button
          asChild
          className="bg-white text-buildora-dark hover:bg-gray-200 border-none px-8 py-6 text-base"
        >
          <Link href="/contact">START A PROJECT</Link>
        </Button>
      </div>
    </section>
  );
}
