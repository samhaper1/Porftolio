import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuGroup,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { ChevronDown, Menu, X } from "lucide-react";
import { useState } from "react";
import AnimatedStartProjectButton from "./AnimatedStartProjectButton";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className="bg-buildora-dark text-white py-4 px-6 md:px-12">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="flex items-center">
          <div className="h-10 w-36 relative">
            <Image
              src="/images/buildora-logo.svg"
              alt="Buildora Digital"
              fill
              className="object-contain"
              priority
            />
          </div>
        </Link>

        {/* Desktop navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link
            href="/"
            className="text-white hover:text-gray-300 font-medium transition-colors"
          >
            HOME
          </Link>
          <Link
            href="/about"
            className="text-white hover:text-gray-300 font-medium transition-colors"
          >
            ABOUT
          </Link>
          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center text-white hover:text-gray-300 font-medium transition-colors">
              SERVICES <ChevronDown className="ml-1 h-4 w-4" />
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-buildora-dark border-buildora-gray w-56">
              <DropdownMenuGroup>
                <DropdownMenuItem asChild>
                  <Link
                    href="/services"
                    className="text-white hover:bg-buildora-accent w-full cursor-pointer"
                  >
                    ALL SERVICES
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-gray-700" />
                <DropdownMenuItem asChild>
                  <Link
                    href="/services/web-design"
                    className="text-white hover:bg-buildora-accent w-full cursor-pointer"
                  >
                    WEB DESIGN
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link
                    href="/services/seo"
                    className="text-white hover:bg-buildora-accent w-full cursor-pointer"
                  >
                    SEO
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link
                    href="/services/content-marketing"
                    className="text-white hover:bg-buildora-accent w-full cursor-pointer"
                  >
                    CONTENT MARKETING
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-gray-700" />
                <DropdownMenuItem asChild>
                  <Link
                    href="/services/restaurant-websites"
                    className="text-white hover:bg-buildora-accent w-full cursor-pointer"
                  >
                    RESTAURANT WEBSITES
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link
                    href="/services/hotel-websites"
                    className="text-white hover:bg-buildora-accent w-full cursor-pointer"
                  >
                    HOTEL RESERVATION
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link
                    href="/services/tech-websites"
                    className="text-white hover:bg-buildora-accent w-full cursor-pointer"
                  >
                    TECH & IT WEBSITES
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuGroup>
            </DropdownMenuContent>
          </DropdownMenu>
          <Link
            href="/work"
            className="text-white hover:text-gray-300 font-medium transition-colors"
          >
            WORK
          </Link>
          <Link
            href="/blog"
            className="text-white hover:text-gray-300 font-medium transition-colors"
          >
            BLOG
          </Link>
        </nav>

        <div className="hidden md:block">
          <AnimatedStartProjectButton />
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden text-white"
          onClick={toggleMobileMenu}
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-buildora-dark py-4">
          <div className="container mx-auto px-4 flex flex-col space-y-4">
            <Link
              href="/"
              className="text-white hover:text-gray-300 font-medium py-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              HOME
            </Link>
            <Link
              href="/about"
              className="text-white hover:text-gray-300 font-medium py-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              ABOUT
            </Link>
            <div className="py-2">
              <div className="font-medium mb-2">SERVICES</div>
              <div className="pl-4 flex flex-col space-y-2">
                <Link
                  href="/services"
                  className="text-white hover:text-gray-300"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  ALL SERVICES
                </Link>
                <Link
                  href="/services/web-design"
                  className="text-white hover:text-gray-300"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  WEB DESIGN
                </Link>
                <Link
                  href="/services/seo"
                  className="text-white hover:text-gray-300"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  SEO
                </Link>
                <Link
                  href="/services/content-marketing"
                  className="text-white hover:text-gray-300"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  CONTENT MARKETING
                </Link>
                <Link
                  href="/services/restaurant-websites"
                  className="text-white hover:text-gray-300"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  RESTAURANT WEBSITES
                </Link>
                <Link
                  href="/services/hotel-websites"
                  className="text-white hover:text-gray-300"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  HOTEL RESERVATION
                </Link>
                <Link
                  href="/services/tech-websites"
                  className="text-white hover:text-gray-300"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  TECH & IT WEBSITES
                </Link>
              </div>
            </div>
            <Link
              href="/work"
              className="text-white hover:text-gray-300 font-medium py-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              WORK
            </Link>
            <Link
              href="/blog"
              className="text-white hover:text-gray-300 font-medium py-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              BLOG
            </Link>
            <Button
              asChild
              className="bg-white text-buildora-dark hover:bg-gray-200 border-none w-full"
            >
              <Link href="/contact" onClick={() => setMobileMenuOpen(false)}>
                START A PROJECT
              </Link>
            </Button>
          </div>
        </div>
      )}
    </header>
  );
}
