import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Monitor, Search, FileEdit, ShoppingBag } from "lucide-react";

const serviceData = [
  {
    icon: <Monitor className="h-12 w-12 mb-6" />,
    title: "Web Design",
    description:
      "Our unique web design capabilities allow us to work with business owners across industries to create minimalistic, highly-engaging websites.",
    link: "/services/web-design",
  },
  {
    icon: <Search className="h-12 w-12 mb-6" />,
    title: "SEO",
    description:
      "Our approach to SEO strategy and implementation will dramatically improve your visibility on Google and other search engines to drive business value.",
    link: "/services/seo",
  },
  {
    icon: <FileEdit className="h-12 w-12 mb-6" />,
    title: "Content Marketing",
    description:
      "We craft in-brand messaging that drives qualified web traffic, builds customer trust, offers unique value, and helps grow your business.",
    link: "/services/content-marketing",
  },
  {
    icon: <ShoppingBag className="h-12 w-12 mb-6" />,
    title: "E-commerce Solutions",
    description:
      "From product listings to payment integration, we create seamless online shopping experiences that convert visitors into customers.",
    link: "/services/e-commerce",
  },
];

export default function ServicesSection() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">
            Our Services
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            From custom web design to content writing and search engine
            optimization, our range of creative digital services will help you
            shine online.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {serviceData.map((service) => (
            <div
              key={service.title}
              className="bg-gray-50 p-8 rounded-lg hover:shadow-lg transition-shadow duration-300"
            >
              {service.icon}
              <h3 className="text-xl font-bold mb-4">{service.title}</h3>
              <p className="text-gray-600 mb-6">{service.description}</p>
              <Button
                asChild
                variant="link"
                className="p-0 text-buildora-accent hover:text-buildora-gray font-medium transition-colors"
              >
                <Link href={service.link}>LEARN MORE</Link>
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
