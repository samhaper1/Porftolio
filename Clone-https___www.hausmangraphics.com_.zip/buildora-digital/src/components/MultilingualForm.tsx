import { useState } from "react";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

// Define translations
const translations = {
  ar: {
    title: "أخبرنا عن مشروعك",
    subtitle: "املأ النموذج أدناه وسنتواصل معك قريبًا",
    business: "ما هو نشاطك التجاري أو المؤسسي؟",
    websiteType: "نوع الموقع الذي ترغب بإنشائه؟",
    options: {
      portfolio: "بورتفوليو",
      showcase: "موقع عرض",
      landing: "صفحة هبوط",
      restaurant: "موقع مطعم",
      hotel: "حجز فندق",
      ecommerce: "متجر إلكتروني",
    },
    projectName: "ما هو اسم مشروعك أو شركتك أو متجرك؟",
    email: "البريد الإلكتروني",
    phone: "رقم الهاتف",
    language: "ما هي لغة الموقع؟",
    languages: {
      arabic: "العربية",
      french: "الفرنسية",
      english: "الإنجليزية",
    },
    logo: "هل تملك شعار (logo)؟",
    logoOptions: {
      yes: "نعم، لدي شعار",
      no: "لا، ليس لدي شعار",
      create: "أريد أن تنشئوا لي واحدا",
    },
    example: "هل لديك مثال لموقع تريد شبيه له؟ (اختياري)",
    submit: "إرسال",
  },
  fr: {
    title: "Parlez-nous de votre projet",
    subtitle: "Remplissez le formulaire ci-dessous et nous vous contacterons bientôt",
    business: "Quelle est votre activité commerciale ou institutionnelle ?",
    websiteType: "Quel type de site souhaitez-vous créer ?",
    options: {
      portfolio: "Portfolio",
      showcase: "Site vitrine",
      landing: "Landing page",
      restaurant: "Site de restaurant",
      hotel: "Réservation d'hôtel",
      ecommerce: "E-commerce",
    },
    projectName: "Quel est le nom de votre projet, entreprise ou boutique ?",
    email: "Email",
    phone: "Numéro de téléphone",
    language: "Quelle est la langue du site ?",
    languages: {
      arabic: "Arabe",
      french: "Français",
      english: "Anglais",
    },
    logo: "Avez-vous un logo ?",
    logoOptions: {
      yes: "Oui, j'ai un logo",
      no: "Non, je n'ai pas de logo",
      create: "Je veux que vous en créiez un pour moi",
    },
    example: "Avez-vous un exemple de site que vous souhaitez imiter ? (facultatif)",
    submit: "Envoyer",
  },
  en: {
    title: "Tell us about your project",
    subtitle: "Fill out the form below and we'll get back to you soon",
    business: "What is your business or institutional activity?",
    websiteType: "What type of website do you want to create?",
    options: {
      portfolio: "Portfolio",
      showcase: "Showcase website",
      landing: "Landing page",
      restaurant: "Restaurant website",
      hotel: "Hotel booking",
      ecommerce: "E-commerce",
    },
    projectName: "What is the name of your project, company, or store?",
    email: "Email",
    phone: "Phone number",
    language: "What is the language of the website?",
    languages: {
      arabic: "Arabic",
      french: "French",
      english: "English",
    },
    logo: "Do you have a logo?",
    logoOptions: {
      yes: "Yes, I have a logo",
      no: "No, I don't have a logo",
      create: "I want you to create one for me",
    },
    example: "Do you have an example of a website you want to mimic? (optional)",
    submit: "Submit",
  },
};

// Define form schema
const formSchema = z.object({
  business: z.string().min(2, {
    message: "Please provide a description of your business.",
  }),
  websiteType: z.string({
    required_error: "Please select a website type.",
  }),
  projectName: z.string().min(2, {
    message: "Please provide your project name.",
  }),
  email: z.string().email({
    message: "Please provide a valid email address.",
  }),
  phone: z.string().min(5, {
    message: "Please provide a valid phone number.",
  }),
  websiteLanguages: z.array(z.string()).min(1, {
    message: "Please select at least one language.",
  }),
  logoStatus: z.string({
    required_error: "Please select an option regarding your logo.",
  }),
  example: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export default function MultilingualForm() {
  // Detect user language
  const detectUserLanguage = () => {
    const language = navigator.language || "en";
    if (language.startsWith("ar")) return "ar";
    if (language.startsWith("fr")) return "fr";
    return "en";
  };

  const [language, setLanguage] = useState("en"); // Default to English

  // Initialize form with default values
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      business: "",
      websiteType: "",
      projectName: "",
      email: "",
      phone: "",
      websiteLanguages: [],
      logoStatus: "",
      example: "",
    },
  });

  // Get current translations
  const t = translations[language as keyof typeof translations];

  // Set the direction based on language
  const direction = language === "ar" ? "rtl" : "ltr";

  // Define website type options
  const websiteTypes = [
    { value: "portfolio", label: t.options.portfolio },
    { value: "showcase", label: t.options.showcase },
    { value: "landing", label: t.options.landing },
    { value: "restaurant", label: t.options.restaurant },
    { value: "hotel", label: t.options.hotel },
    { value: "ecommerce", label: t.options.ecommerce },
  ];

  // Define logo options
  const logoOptions = [
    { value: "yes", label: t.logoOptions.yes },
    { value: "no", label: t.logoOptions.no },
    { value: "create", label: t.logoOptions.create },
  ];

  // Define language options for the website
  const languageOptions = [
    { value: "arabic", label: t.languages.arabic },
    { value: "french", label: t.languages.french },
    { value: "english", label: t.languages.english },
  ];

  // Handle form submission
  const onSubmit = (data: FormValues) => {
    console.log("Form data:", data);
    // Here you would typically send this data to your backend
    alert("Form submitted successfully!");
  };

  return (
    <div className="multilingual-form" dir={direction}>
      {/* Language selector */}
      <div className="language-selector">
        <button
          onClick={() => setLanguage("ar")}
          className={`${language === "ar" ? "active bg-buildora-accent text-white" : "bg-gray-200"}`}
          type="button"
        >
          العربية
        </button>
        <button
          onClick={() => setLanguage("fr")}
          className={`${language === "fr" ? "active bg-buildora-accent text-white" : "bg-gray-200"}`}
          type="button"
        >
          Français
        </button>
        <button
          onClick={() => setLanguage("en")}
          className={`${language === "en" ? "active bg-buildora-accent text-white" : "bg-gray-200"}`}
          type="button"
        >
          English
        </button>
      </div>

      <div className="form-header mb-8">
        <h2 className="text-2xl font-bold mb-2">{t.title}</h2>
        <p className="text-gray-600">{t.subtitle}</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Business Activity */}
          <FormField
            control={form.control}
            name="business"
            render={({ field }) => (
              <FormItem className="form-field">
                <FormLabel className="font-medium">{t.business}</FormLabel>
                <FormControl>
                  <textarea
                    className="input-field min-h-24"
                    placeholder={t.business}
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Website Type */}
          <FormField
            control={form.control}
            name="websiteType"
            render={({ field }) => (
              <FormItem className="form-field">
                <FormLabel className="font-medium">{t.websiteType}</FormLabel>
                <FormControl>
                  <select
                    className="select-field"
                    {...field}
                  >
                    <option value="" disabled>
                      {t.websiteType}
                    </option>
                    {websiteTypes.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Project Name */}
          <FormField
            control={form.control}
            name="projectName"
            render={({ field }) => (
              <FormItem className="form-field">
                <FormLabel className="font-medium">{t.projectName}</FormLabel>
                <FormControl>
                  <input
                    type="text"
                    className="input-field"
                    placeholder={t.projectName}
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Contact Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem className="form-field">
                  <FormLabel className="font-medium">{t.email}</FormLabel>
                  <FormControl>
                    <input
                      type="email"
                      className="input-field"
                      placeholder={t.email}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem className="form-field">
                  <FormLabel className="font-medium">{t.phone}</FormLabel>
                  <FormControl>
                    <input
                      type="tel"
                      className="input-field"
                      placeholder={t.phone}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Website Languages */}
          <FormField
            control={form.control}
            name="websiteLanguages"
            render={() => (
              <FormItem className="form-field">
                <FormLabel className="font-medium">{t.language}</FormLabel>
                <div className="flex flex-col gap-2">
                  {languageOptions.map((option) => (
                    <div key={option.value} className="checkbox-field">
                      <input
                        type="checkbox"
                        id={`lang-${option.value}`}
                        value={option.value}
                        onChange={(e) => {
                          const currentValues = form.getValues().websiteLanguages || [];
                          if (e.target.checked) {
                            form.setValue("websiteLanguages", [
                              ...currentValues,
                              option.value,
                            ]);
                          } else {
                            form.setValue(
                              "websiteLanguages",
                              currentValues.filter((val) => val !== option.value)
                            );
                          }
                        }}
                        className="mr-2"
                      />
                      <label htmlFor={`lang-${option.value}`}>{option.label}</label>
                    </div>
                  ))}
                </div>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Logo Status */}
          <FormField
            control={form.control}
            name="logoStatus"
            render={({ field }) => (
              <FormItem className="form-field">
                <FormLabel className="font-medium">{t.logo}</FormLabel>
                <div className="flex flex-col gap-2">
                  {logoOptions.map((option) => (
                    <div key={option.value} className="checkbox-field">
                      <input
                        type="radio"
                        id={`logo-${option.value}`}
                        value={option.value}
                        checked={field.value === option.value}
                        onChange={() => form.setValue("logoStatus", option.value)}
                        className="mr-2"
                      />
                      <label htmlFor={`logo-${option.value}`}>{option.label}</label>
                    </div>
                  ))}
                </div>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Example Website */}
          <FormField
            control={form.control}
            name="example"
            render={({ field }) => (
              <FormItem className="form-field">
                <FormLabel className="font-medium">{t.example}</FormLabel>
                <FormControl>
                  <input
                    type="text"
                    className="input-field"
                    placeholder={t.example}
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Submit Button */}
          <Button
            type="submit"
            className="w-full bg-buildora-dark hover:bg-buildora-accent text-white py-6"
          >
            {t.submit}
          </Button>
        </form>
      </Form>
    </div>
  );
}
