import Link from "next/link";
import { Button } from "@/components/ui/button";
import AnimatedStartProjectButton from "./AnimatedStartProjectButton";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="hero-section bg-buildora-dark relative overflow-hidden">
      {/* Video background */}
      <div className="absolute inset-0 z-0 opacity-30">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover"
        >
          <source src="https://placehold.co/600x400/mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
        <div className="absolute inset-0 bg-black opacity-60" />
      </div>

      {/* Content */}
      <div className="container mx-auto px-6 py-24 md:py-32 relative z-10">
        <div className="max-w-3xl space-y-8">
          <motion.h1
            className="text-4xl md:text-6xl font-bold font-heading"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            Crafting Websites
            <br />
            <span className="block mt-2">With Purpose & Impact</span>
          </motion.h1>

          <motion.p
            className="text-lg md:text-xl text-gray-300 max-w-2xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            We help your business compete and succeed in this ever-changing
            digital world with stunning websites and effective online strategies.
          </motion.p>

          <motion.div
            className="flex flex-col sm:flex-row gap-4 pt-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <Button
              asChild
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-buildora-dark px-8 py-6 text-base"
            >
              <Link href="/services">SERVICES</Link>
            </Button>

            <div className="hidden sm:block">
              <AnimatedStartProjectButton />
            </div>

            <div className="block sm:hidden">
              <Button
                asChild
                className="bg-white text-buildora-dark hover:bg-gray-200 border-none px-8 py-6 text-base w-full"
              >
                <Link href="/contact">GET A QUOTE</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
