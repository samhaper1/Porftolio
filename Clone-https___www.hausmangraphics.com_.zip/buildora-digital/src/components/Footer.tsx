import Link from "next/link";
import Image from "next/image";
import { Facebook, Instagram, Twitter, Mail, Phone } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-buildora-dark text-white pt-16 pb-8">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Column 1 - Logo and description */}
          <div className="space-y-6">
            <div className="h-10 w-36 relative">
              <Image
                src="/images/buildora-logo.svg"
                alt="Buildora Digital"
                fill
                className="object-contain"
              />
            </div>
            <p className="text-gray-300 mt-4 max-w-sm">
              From custom web design to content writing and digital marketing, our range of creative digital services will help your business shine online.
            </p>
            <Link
              href="/contact"
              className="inline-block bg-white text-buildora-dark hover:bg-gray-200 px-6 py-3 font-medium rounded transition-colors"
            >
              START YOUR PROJECT
            </Link>
          </div>

          {/* Column 2 - Quick links */}
          <div>
            <h3 className="text-xl font-bold mb-6">Our Services</h3>
            <ul className="space-y-4">
              <li>
                <Link
                  href="/services/web-design"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  Web Design
                </Link>
              </li>
              <li>
                <Link
                  href="/services/seo"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  SEO
                </Link>
              </li>
              <li>
                <Link
                  href="/services/content-marketing"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  Content Marketing
                </Link>
              </li>
              <li>
                <Link
                  href="/services/e-commerce"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  E-commerce Solutions
                </Link>
              </li>
              <li>
                <Link
                  href="/services/graphics"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  Digital Graphics + Artwork
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3 - Contact info */}
          <div>
            <h3 className="text-xl font-bold mb-6">Connect with us</h3>
            <div className="space-y-4">
              <div className="flex items-center">
                <Mail className="h-5 w-5 mr-3 text-gray-300" />
                <a
                  href="mailto:info@buildora.digital"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  info@buildora.digital
                </a>
              </div>
              <div className="flex items-center">
                <Phone className="h-5 w-5 mr-3 text-gray-300" />
                <a
                  href="tel:+1234567890"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  +123 456 7890
                </a>
              </div>
              <div className="pt-4">
                <div className="flex space-x-4">
                  <a
                    href="https://www.instagram.com/buildora.digital"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-300 hover:text-white transition-colors"
                    aria-label="Instagram"
                  >
                    <Instagram className="h-6 w-6" />
                  </a>
                  <a
                    href="https://www.facebook.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-300 hover:text-white transition-colors"
                    aria-label="Facebook"
                  >
                    <Facebook className="h-6 w-6" />
                  </a>
                  <a
                    href="https://www.twitter.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-300 hover:text-white transition-colors"
                    aria-label="Twitter"
                  >
                    <Twitter className="h-6 w-6" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © Buildora Digital {new Date().getFullYear()} / Designed by{" "}
            <Link
              href="/"
              className="text-gray-300 hover:text-white transition-colors"
            >
              Buildora Digital
            </Link>
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link
              href="/privacy"
              className="text-gray-400 hover:text-white text-sm transition-colors"
            >
              Privacy Policy
            </Link>
            <Link
              href="/terms"
              className="text-gray-400 hover:text-white text-sm transition-colors"
            >
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
