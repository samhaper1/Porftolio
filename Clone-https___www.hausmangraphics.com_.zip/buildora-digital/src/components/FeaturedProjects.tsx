import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";

// Sample project data
const projects = [
  {
    id: "project1",
    title: "TECH INNOVATORS",
    category: "IT & DIGITAL",
    imageSrc: "https://placehold.co/600x400/333/white?text=Tech+Project",
    link: "/projects/tech-innovators",
  },
  {
    id: "project2",
    title: "MODERN BUILDERS",
    category: "CONSTRUCTION, ARCHITECTURE",
    imageSrc: "https://placehold.co/600x400/333/white?text=Construction+Project",
    link: "/projects/modern-builders",
  },
  {
    id: "project3",
    title: "BEAUTY BRAND",
    category: "BEAUTY, ECOMMERCE",
    imageSrc: "https://placehold.co/600x400/333/white?text=Beauty+Project",
    link: "/projects/beauty-brand",
  },
  {
    id: "project4",
    title: "AUTO SERVICES",
    category: "AUTOMOTIVE",
    imageSrc: "https://placehold.co/600x400/333/white?text=Auto+Project",
    link: "/projects/auto-services",
  },
];

export default function FeaturedProjects() {
  return (
    <section className="py-20 bg-buildora-dark text-white">
      <div className="container mx-auto px-6">
        <div className="flex justify-between items-center mb-16">
          <h2 className="text-3xl font-bold">
            Featured Projects
          </h2>
          <Link href="/work" className="text-white hover:text-gray-300 border-b border-white pb-1 transition-colors">
            View all projects
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {projects.map((project) => (
            <div key={project.id} className="group relative overflow-hidden">
              <Link href={project.link}>
                <div className="relative h-64 overflow-hidden">
                  <Image
                    src={project.imageSrc}
                    alt={project.title}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-70" />
                </div>

                <div className="absolute bottom-0 left-0 p-6 w-full">
                  <div className="text-xs font-medium mb-2 opacity-80">{project.category}</div>
                  <h3 className="text-xl font-bold">{project.title}</h3>

                  <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <span className="text-sm font-medium border-b border-white pb-1">
                      VIEW PROJECT
                    </span>
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button
            asChild
            variant="outline"
            className="border-white text-white hover:bg-white hover:text-buildora-dark px-8 py-6 text-base"
          >
            <Link href="/work">EXPLORE ALL PROJECTS</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
