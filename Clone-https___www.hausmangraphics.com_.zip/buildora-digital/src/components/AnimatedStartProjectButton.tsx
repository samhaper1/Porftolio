import { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AnimatedStartProjectButton() {
  const [hovered, setHovered] = useState(false);

  return (
    <Link href="/contact">
      <motion.div
        className="bg-white text-buildora-dark hover:bg-gray-100 py-3 px-6 rounded-full flex items-center justify-center whitespace-nowrap font-medium"
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        initial={{ scale: 1 }}
        whileHover={{
          scale: 1.05,
          transition: { duration: 0.2 }
        }}
      >
        <span className="mr-2">START A PROJECT</span>
        <motion.div
          initial={{ x: 0 }}
          animate={{ x: hovered ? 5 : 0 }}
          transition={{ duration: 0.2 }}
        >
          <ArrowRight className="h-4 w-4" />
        </motion.div>
      </motion.div>
    </Link>
  );
}
